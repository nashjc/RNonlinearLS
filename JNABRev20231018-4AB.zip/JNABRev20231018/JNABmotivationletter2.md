---
output: pdf_document
fontsize: 12pt
---

\thispagestyle{empty}
\today

Editor   
The R Journal  
\bigskip

Dear Professors Cook / Hyndman,
\bigskip

Please consider the resubmission of our article [RJournal 2023-15] which has been retitled "A Comparison of R Tools for Nonlinear Least Squares Modeling" for publication in the R Journal.

We have followed the suggestions of the associate editor and believe this makes for a considerable improvement
in the readability and utility of the article.


\bigskip
\bigskip

Regards,
    
    
    
    
John Nash  
Telfer School of Management  
University of Ottawa  
Ottawa, ON K1N 6N5 Canada  
profjcnash@gmail.com  
\bigskip

